<?php

include '../config/koneksi.php';
include '../library/controllers.php';

$perintah = new oop();

@$table = "tb_orangtua_ibu";
@$where = "id_ibu = $_GET[id]";
@$redirect = "?menu=orangtua_ibu";
@$tanggal = $_POST['thn'] . "-" . $_POST['bln'] . "-" . $_POST['tgl'];
@$field = array('nama_ibu' => $_POST['nama_ibu'], 'tempat_lahir_ibu' => $_POST['tempat_lahir_ibu'], 'tanggal_lahir_ibu' => $tanggal, 'pekerjaan_ibu' => $_POST['pekerjaan_ibu'], 'pendidikan_terakhir_ibu' => $_POST['pendidikan_terakhir_ibu'], 'kewarganegaraan_ibu' => $_POST['kewarganegaraan_ibu'],'agama_ibu' => $_POST['agama_ibu'], 'no_hp_ibu' => $_POST['no_hp_ibu']);    
    


if (isset($_POST['simpan'])) {
    $perintah->simpan($con, $table, $field, $redirect);
}

if (isset($_GET['hapus'])) {
    $perintah->hapus($con, $table, $where, $redirect);
}

if (isset($_GET['edit'])) {
    $edit = $perintah->edit($con, $table, $where);
    $date = explode("-", $edit['tanggal_lahir_ibu']);
    $thn = $date[0];
    $bln = $date[1];
    $tgl = $date[2];
}

if (isset($_POST['ubah'])) {
    $perintah->ubah($con, $table, $field, $where, $redirect);
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Ibu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
<body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<form action="" method="post" enctype="multipart/form-data">
    <table>
    <div class="container">
    <br>
    <div class="form-row">
        <div class="form-group col-md-6">
			<h6>Nama Ibu</h6>
			<input type="text" class="form-control" name="nama_ibu" placeholder="Nama Ibu" value="<?php echo @$edit['nama_ibu'] ?>" required>
		</div>
        <div class="form-group col-md-6">
			<h6>Tempat Lahir</h6>
			<input type="text" class="form-control" name="tempat_lahir_ibu" placeholder="Tempat lahir" value="<?php echo @$edit['tempat_lahir_ibu'] ?>" required>
		</div>
	</div>
    <div class="form-row">
    <div class="form-group col-md-6">
			<h6>Tanggal Lahir</h6>
            <div class="form-group">
             <select name="tgl" class="form-control col-md-3 custom-control-inline" required>
                    <option value="<?php echo @$tgl ?>"><?php echo @$tgl ?></option>
                    <?php
                    for ($tgl = 1; $tgl <= 31; $tgl++) {
                        if ($tgl <= 9) {
                            ?>
                            <option value="<?php echo "0" . $tgl; ?>"><?php echo "0" . $tgl; ?></option>
                        <?php } else { ?>
                            <option value="<?php echo $tgl; ?>"><?php echo $tgl; ?></option>            
                        <?php }
                    } ?>
                </select>

                <select name="bln" class="form-control col-md-3 custom-control-inline" required>
                    <option value="<?php echo @$bln; ?>"><?php echo @$bln; ?></option>
                    <?php
                    for ($bln = 1; $bln <= 12; $bln++) {
                        if ($bln <= 9) {
                            ?>
                            <option value="<?php echo "0" . $bln; ?>"><?php echo "0" . $bln; ?></option>
                        <?php } else {
                            ; ?>
                            <option value="<?php echo $bln; ?>"><?php echo $bln; ?></option>
                        <?php }
                            } ?>
                </select>

                <select name="thn" class="form-control col-md-4  custom-control-inline" required>
                    <option value="<?php echo @$thn; ?>"><?php echo @$thn; ?></option>
                    <?php
                    for ($thn = 1996; $thn <= 2005; $thn++) {
                        ?>
                        <option value="<?php echo $thn; ?>"><?php echo $thn; ?></option>
                    <?php } ?>
                </select>
                </div>
                </div>
            </td>
        </tr>
        <div class="form-group col-md-6">
			<h6>Pekerjaaan</h6>
			<input type="text" class="form-control" name="pekerjaan_ibu" placeholder="Pekerjaan" value="<?php echo @$edit['pekerjaan_ibu'] ?>" required>
		</div>
	</div>
    <div class="form-row">
        <div class="form-group col-md-6">
			<h6>Pendidikan Terakhir</h6>
			<input type="text" class="form-control" name="pendidikan_terakhir_ibu" placeholder="Pendidikan Terakhir" value="<?php echo @$edit['pendidikan_terakhir_ibu'] ?>" required>
		</div>
	
        <div class="form-group col-md-6">
			<h6>Kewarganegaraan</h6>
			<input type="text" class="form-control" name="kewarganegaraan_ibu" placeholder="Kewarganegaraan" value="<?php echo @$edit['kewarganegaraan_ibu'] ?>" required>
		</div>
	</div>
    <div class="form-row">
        <div class="form-group col-md-6">
			<h6>Agama</h6>
			<input type="text" class="form-control" name="agama_ibu" placeholder="Agama" value="<?php echo @$edit['agama_ibu'] ?>" required>
		</div>
        <div class="form-group col-md-6">
			<h6>No Hp/Wa</h6>
			<input type="text" class="form-control" name="no_hp_ibu" placeholder="No Hp/WA" value="<?php echo @$edit['no_hp_ibu'] ?>" required>
		</div>
	</div>
    <div class="form-row">
    <div class="form-group col-md-2">
    <?php if (@$_GET['id'] == "") { ?>
        <input type="submit" href="?menu=orangtua_ibu" class="form-control btn btn-primary" name="simpan" value="Simpan">
                <?php } else { ?>
        <input type="submit" href="?menu=orangtua_ibu" class="form-control btn btn-primary" name="ubah" value="Ubah">
                    <?php } ?>
		</div>
              <div>
</div>
        </tr>
    </table>
    <div class="container">
    <table class="table table-striped">
 				<tr>
 					<td scope="col">No.</td>
 					<td scope="col">Nama Ibu</td>
 					<td scope="col">tempat_lahir</td>
 					<td scope="col">tanggal_lahir</td>
 					<td scope="col">pekerjaan</td>
 					<td scope="col">pendidikan Terakhir</td>
 					<td scope="col">Kewarganegaraan</td>
                    <td scope="col">agama</td>
                    <td scope="col">No Hp</td>
                    <td colspan="3">Aksi</td>
 				</tr>
                 <?php 
 				$no = 0;
 				$sql = mysqli_query($con, "SELECT * FROM tb_orangtua_ibu");
 				while ($r = mysqli_fetch_array($sql)){
 					$no++;
 				 ?>
 				 <tr>
 				 	<td><?php echo $no; ?></td>
                    <td><?php echo $r['nama_ibu']; ?></td>
 				 	<td><?php echo $r['tempat_lahir_ibu']; ?></td>
 				 	<td><?php echo $r['tanggal_lahir_ibu']; ?></td>
 				 	<td><?php echo $r['pekerjaan_ibu']; ?></td>
                    <td><?php echo $r['pendidikan_terakhir_ibu']; ?></td> 
                    <td><?php echo $r['kewarganegaraan_ibu']; ?></td>
                    <td><?php echo $r['agama_ibu']; ?></td>
                    <td><?php echo $r['no_hp_ibu']; ?></td>
 				 	<td><a href="?menu=orangtua_ibu&hapus&id=<?php echo $r['id_ibu'] ?> "on_Click = "return confirm('Anda Yakin?')">Hapus</a></td>
                    <td><a href="?menu=orangtua_ibu&edit&id=<?php echo $r['id_ibu'] ?>">Edit</a></td>
 			     
                  </tr>
 				<?php  }?>
 			</table>
             </div>
    </form>
</body>
</html>
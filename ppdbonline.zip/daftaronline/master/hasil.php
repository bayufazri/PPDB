<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style type="text/css">
        body {
	color: #fff;
	background: url('../image/gedung.jpg');
	background-size: cover;
}
        
    </style>
    <title>Hasil Survey</title>
</head>
<body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<div class="container">

<h1></h1>
<div class="card text-white bg-primary mb-3" style="max-width: 1100px;">
  <div class="row no-gutters">
    <div class="col-md-4">
      <img src="../image/garut.jpg" class="card-img" alt="...">
    </div>
    <div class="col-md-8">
  <div class="card-body">
    <h2 class="card-title">Selanjutnya...</td></h2>
    <h4>Tunggu info lebih lanjut untuk melaksanakan seleksi!</h4>
    <h3>__________________________________________________</h3>
    <h4>Siapkan Berkas untuk dibawa saat seleksi:</h4>
    <h5>1. Fotokopi Raport SMP Kelas 7-9 Semester 1</h5>
    <h5>2. Fotokopi Akte Kelahiran</h5>
    <h5>3. Fotokopi Kartu Keluarga</h5>
    <h5>4. Pas Photo Berwarna (Berkemeja) Ukuran 3 X 4(6 Lembar)</h5>
    <a href="logout.php" class="btn btn-outline-warning">keluar</a>
  </div>
  </div>
</div>
</html>
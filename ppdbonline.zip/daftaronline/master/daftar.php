<?php

include '../config/koneksi.php';
include '../library/controllers.php';

$perintah = new oop();

@$table = "tb_daftar";
@$where = "id_daftar= $_GET[id]";
@$redirect = "?menu=siswa";
@$tanggal = $_POST['thn'] . "-" . $_POST['bln'] . "-" . $_POST['tgl'];
@$folder = "../foto";
@$field = array('nama_lengkap' => $_POST['nama_lengkap'], 'jenis_kelamin' => $_POST['jenis_kelamin'], 'tempat_lahir' => $_POST['tempat_lahir'],'tanggal_lahir' => $tanggal, 'agama' => $_POST['agama'], 'nama_ayah' => $_POST['nama_ayah'], 'nama_ibu' => $_POST['nama_ibu'], 'no_hp' => $_POST['no_hp'], 'jalan' => $_POST['jalan'], 'rt' => $_POST['rt'], 'rw' => $_POST['rw'], 'desa_kelurahan' => $_POST['desa_kelurahan'], 'kecamatan' => $_POST['kecamatan'], 'kota_kabupaten' => $_POST['kota_kabupaten'], 'email' => $_POST['email'], 'asal_smp' => $_POST['asal_smp'], 'nisn' => $_POST['nisn'], 'no_kk' => $_POST['no_kk'], 'nik_siswa' => $_POST['nik_siswa'], 'nik_ayah' => $_POST['nik_ayah'], 'nik_ibu' => $_POST['nik_ibu'], 'pekerjaan_ayah' => $_POST['pekerjaan_ayah'], 'pekerjaan_ibu' => $_POST['pekerjaan_ibu'], 'pekerjaan_wali' => $_POST['pekerjaan_wali'], 'minat_bidang' => $_POST['minat_bidang'], 'minat_program' => $_POST['minat_program']);    
   

if (isset($_POST['simpan'])) {
  $perintah->simpan($con, $table, $field, $redirect);
}

if (isset($_GET['hapus'])) {
    $perintah->hapus($con, $table, $where, $redirect);
}

if (isset($_GET['edit'])) {
    $edit = $perintah->edit($con, $table, $where);
    if ($edit['jenis_kelamin'] == "L") {
        $l = "checked";
    } else {
        $p = "checked";
    }
    $date = explode("-", $edit['tanggal_lahir']);
    $thn = $date[0];
    $bln = $date[1];
    $tgl = $date[2];
}

if (isset($_POST['ubah'])) {
  $perintah->ubah($con, $table, $field, $where, $redirect);
    
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style type="text/css">
        .card {
        margin: 100px auto;
        width: 300px auto;
        padding: 10px;
        background: lightblue;
    }  
   body {
	color: #fff;
	background: url('../image/gedung.jpg');
	background-size: cover;
}
    </style>
    <title>form pendaftaran</title>
  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<form action="" method="post" enctype="multipart/form-data">
<form>
<table>
<div class="card text-left border-light bg-light" style="width: 60rem; height:65rem;">
    <div class="container">
    <h3 align="center">Lengkapi Data Dibawah ini !</h3>

	<div class="form-row">
		<div class="form-group col-md-6">
			<h6>Nama Lengkap</h6>
			<input type="text" class="form-control" name="nama_lengkap" placeholder="Nama Lengkap" required>
		</div>
        <h6>Jenis Kelamin</h6>
        <div class="form-group col-md-2">
	<div class="custom-control custom-radio custom-control-inline ">
		<input type="radio" id="ContohRadio1" name="jenis_kelamin" value="laki-laki" class="custom-control-input" required>
		<label class="custom-control-label" for="ContohRadio1">Laki-laki</label>
	</div>
	<div class="custom-control custom-radio custom-control-inline">
		<input type="radio" id="ContohRadio2" name="jenis_kelamin" value="perempuan"  class="custom-control-input" required>
		<label class="custom-control-label" for="ContohRadio2">Perempuan</label>
	</div>
		</div>
	</div>
 
	<div class="form-row">
	<div class="form-group col-md-6">
			<h6>Tempat Lahir</h6>
			<input type="text" class="form-control" name="tempat_lahir" placeholder="tempat_lahir" required>
		</div>
		<div class="form-group col-md-6">
			<h6>Tanggal Lahir</h6>
            <div class="form-group">
             <select name="tgl" class="form-control col-md-3 custom-control-inline" required>
                    <option value="<?php echo @$tgl ?>"><?php echo @$tgl ?></option>
                    <?php
                    for ($tgl = 1; $tgl <= 31; $tgl++) {
                        if ($tgl <= 9) {
                            ?>
                            <option value="<?php echo "0" . $tgl; ?>"><?php echo "0" . $tgl; ?></option>
                        <?php } else { ?>
                            <option value="<?php echo $tgl; ?>"><?php echo $tgl; ?></option>            
                        <?php }
                    } ?>
                </select>

                <select name="bln" class="form-control col-md-3 custom-control-inline" required>
                    <option value="<?php echo @$bln; ?>"><?php echo @$bln; ?></option>
                    <?php
                    for ($bln = 1; $bln <= 12; $bln++) {
                        if ($bln <= 9) {
                            ?>
                            <option value="<?php echo "0" . $bln; ?>"><?php echo "0" . $bln; ?></option>
                        <?php } else {
                            ; ?>
                            <option value="<?php echo $bln; ?>"><?php echo $bln; ?></option>
                        <?php }
                            } ?>
                </select>

                <select name="thn" class="form-control col-md-4  custom-control-inline" required>
                    <option value="<?php echo @$thn; ?>"><?php echo @$thn; ?></option>
                    <?php
                    for ($thn = 1996; $thn <= 2005; $thn++) {
                        ?>
                        <option value="<?php echo $thn; ?>"><?php echo $thn; ?></option>
                    <?php } ?>
                </select>
                </div>
                </div>
                </div>
            <div class="form-row">
		<div class="form-group col-md-6">
			<h6>Agama</h6>
			<input type="text" class="form-control" name="agama" placeholder="Agama" required>
		</div>
        <div class="form-group col-md-6">
			<h6>Nama Ayah</h6>
			<input type="text" class="form-control" name="nama_ayah" placeholder="Nama Ayah" required>
		</div>
	</div>
    <div class="form-row">
		<div class="form-group col-md-6">
			<h6>Nama Ibu</h6>
			<input type="text" class="form-control" name="nama_ibu" placeholder="Nama Ibu" required>
		</div>
        <div class="form-group col-md-6">
			<h6>No Hp</h6>
			<input type="text" class="form-control" name="no_hp" placeholder="No Hp" required>
		</div>
	</div>
    <div class="form-row">
		<div class="form-group col-md-4">
			<h6>Jalan</h6>
			<input type="text" class="form-control" name="jalan" placeholder="Jalan" required>
		</div>
        <div class="form-group col-md-4">
			<h6>Rt</h6>
			<input type="text" class="form-control" name="rt" placeholder="Rt" required>
		</div>
        <div class="form-group col-md-4">
			<h6>Rw</h6>
			<input type="text" class="form-control" name="rw" placeholder="Rw" required>
		</div>
	</div>
    <div class="form-row">
		<div class="form-group col-md-4">
			<h6>Desa / Kelurahan<h6>
			<input type="text" class="form-control" name="desa_kelurahan" placeholder="Desa / Kelurahan" required>
		</div>
        <div class="form-group col-md-4">
			<h6>Kecamatan</h6>
			<input type="text" class="form-control" name="kecamatan" placeholder="Kecamatan" required>
		</div>
        <div class="form-group col-md-4">
			<h6>Kota / Kabupaten</h6>
			<input type="text" class="form-control" name="kota_kabupaten" placeholder="Kota / Kabupaten" required>
		</div>
	</div>
    <div class="form-row">
		<div class="form-group col-md-6">
			<h6>Email</h6>
			<input type="text" class="form-control" name="email" placeholder="Email" required>
		</div>
        <div class="form-group col-md-6">
			<h6>Asal SMP</h6>
			<input type="text" class="form-control" name="asal_smp" placeholder="Asal SMP" required>
		</div>
	</div>
    <div class="form-row">
		<div class="form-group col-md-6">
			<h6>NISN</h6>
			<input type="text" class="form-control" name="nisn" placeholder="NISN" required>
		</div>
        <div class="form-group col-md-6">
			<h6>No Kartu Keluarga</h6>
			<input type="text" class="form-control" name="no_kk" placeholder="No Kartu Keluarga" required>
		</div>
	</div>
    <div class="form-row">
		<div class="form-group col-md-4">
			<h6>NIK Siswa</h6>
			<input type="text" class="form-control" name="nik_siswa" placeholder="NIK Siswa" required>
		</div>
        <div class="form-group col-md-4">
			<h6>NIK Ayah</h6>
			<input type="text" class="form-control" name="nik_ayah" placeholder="NIK Ayah" required>
		</div>
        <div class="form-group col-md-4">
			<h6>NIK Ibu</h6>
			<input type="text" class="form-control" name="nik_ibu" placeholder="NIK Ibu" required>
		</div>
	</div>
    <div class="form-row">
		<div class="form-group col-md-4">
			<h6>Pekerjaan Ayah</h6>
			<input type="text" class="form-control" name="pekerjaan_ayah" placeholder="Pekerjaan Ayah" required>
		</div>
        <div class="form-group col-md-4">
			<h6>Pekerjaan Ibu</h6>
			<input type="text" class="form-control" name="pekerjaan_ibu" placeholder="Pekerjaan Ibu" required>
		</div>
        <div class="form-group col-md-4">
			<h6>Pekerjaan Wali</h6>
			<input type="text" class="form-control" name="pekerjaan_wali" placeholder="Pekerjaan Wali" required>
		</div>
	</div>
    <div class="form-row">
		<div class="form-group col-md-4">
			<label for="contoh1">Minat Bidang</label>
			<input type="text" class="form-control" name="minat_bidang" placeholder="Minat Bidang" required>
		</div>
        <div class="form-group col-md-4">
			<label for="contoh1">Minat Program</label>
			<input type="text" class="form-control" name="minat_program" placeholder="Minat Program" required>
		</div>
        <div class="form-group col-md-2">
			<label for="contoh1">....</label>
            <a href="hasil.php" class="form-control btn btn-primary" name="simpan">Selesai</a>
		</div>
              <div>
              </form>
    </form>
    </div>
</body>
</html>
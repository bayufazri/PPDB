<?php

include '../config/koneksi.php';
include '../library/controllers.php';

$perintah = new oop();

@$table = "tb_raport";
@$where = "id_raport = $_GET[id]";
@$redirect = "?menu=raport";
@$field = array('nama' => $_POST['nama'], 'pai' => $_POST['pai'], 'bin' => $_POST['bin'], 'bing' => $_POST['bing'], 'mtk' => $_POST['mtk'],'ipa' => $_POST['ipa'], 'ips' => $_POST['ips'] , 'prestasi' => $_POST['prestasi']);    
    


if (isset($_POST['simpan'])) {
    $perintah->simpan($con, $table, $field, $redirect);
}

if (isset($_GET['hapus'])) {
    $perintah->hapus($con, $table, $where, $redirect);
}

if (isset($_GET['edit'])) {
    $edit = $perintah->edit($con, $table, $where);
}

if (isset($_POST['ubah'])) {
    $perintah->ubah($con, $table, $field, $where, $redirect);
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raport</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
<body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<form action="" method="post" enctype="multipart/form-data">
    <table>
    <div class="container">
    <br>
    <div class="form-row">
        <div class="form-group col-md-12">
			<h6>Nama</h6>
			<input type="text" class="form-control" name="nama" placeholder="Nama Murid" value="<?php echo @$edit['nama'] ?>" required>
		</div>
	</div>
    <div class="form-row">
        <div class="form-group col-md-4">
			<h6>Pendidikan Agama</h6>
			<input type="text" class="form-control" name="pai" placeholder="Pendidikan Agama" value="<?php echo @$edit['pai'] ?>" required>
		</div>
        <div class="form-group col-md-4">
			<h6>B Indonesia</h6>
			<input type="text" class="form-control" name="bin" placeholder="Bahasa Indonesia" value="<?php echo @$edit['bin'] ?>" required>
		</div>
        <div class="form-group col-md-4">
			<h6>B Inggris</h6>
			<input type="text" class="form-control" name="bing" placeholder="Bahasa Inggris" value="<?php echo @$edit['bing'] ?>" required>
		</div>
	</div>
    <div class="form-row">
        <div class="form-group col-md-4">
			<h6>Matematika</h6>
			<input type="text" class="form-control" name="mtk" placeholder="Matematika" value="<?php echo @$edit['mtk'] ?>" required>
		</div>
        <div class="form-group col-md-4">
			<h6>IPA</h6>
			<input type="text" class="form-control" name="ipa" placeholder="IPA" value="<?php echo @$edit['ipa'] ?>" required>
		</div>
        <div class="form-group col-md-4">
			<h6>IPS</h6>
			<input type="text" class="form-control" name="ips" placeholder="IPS" value="<?php echo @$edit['ips'] ?>" required>
		</div>
	</div>
    
    <div class="form-row">
        <div class="form-group col-md-12">
			<h6>Prestasi</h6>
			<input type="text" class="form-control" name="prestasi" placeholder="Prestasi" value="<?php echo @$edit['prestasi'] ?>" required>
		</div>
	</div>
    <div class="form-row">
    <div class="form-group col-md-2">
    <?php if (@$_GET['id'] == "") { ?>
        <input type="submit" href="?menu=raport" class="form-control btn btn-primary" name="simpan" value="Simpan">
                <?php } else { ?>
        <input type="submit" href="?menu=raport" class="form-control btn btn-primary" name="ubah" value="Ubah">
                    <?php } ?>
		</div>
              <div>
</div>
        </tr>
    </table>
    <div class="container">
    <table class="table table-striped">
 				<tr>
 					<td scope="col">No.</td>
 					<td scope="col">Nama</td>
 					<td scope="col">Pendidikan Agama</td>
 					<td scope="col">B Indonesia</td>
 					<td scope="col">B Inggris</td>
 					<td scope="col">Matematika</td>
 					<td scope="col">IPA</td>
                    <td scope="col">IPS</td>
                    <td scope="col">Prestasi</td>
                    <td colspan="3">Aksi</td>
 				</tr>
                 <?php 
 				$no = 0;
 				$sql = mysqli_query($con, "SELECT * FROM tb_raport");
 				while ($r = mysqli_fetch_array($sql)){
 					$no++;
 				 ?>
 				 <tr>
 				 	<td><?php echo $no; ?></td>
                    <td><?php echo $r['nama']; ?></td>
 				 	<td><?php echo $r['pai']; ?></td>
 				 	<td><?php echo $r['bin']; ?></td>
 				 	<td><?php echo $r['bing']; ?></td>
                    <td><?php echo $r['mtk']; ?></td> 
                    <td><?php echo $r['ipa']; ?></td>
                    <td><?php echo $r['ips']; ?></td>
                    <td><?php echo $r['prestasi']; ?></td>
 				 	<td><a href="?menu=raport&hapus&id=<?php echo $r['id_raport'] ?> "on_Click = "return confirm('Anda Yakin?')">Hapus</a></td>
                    <td><a href="?menu=raport&edit&id=<?php echo $r['id_raport'] ?>">Edit</a></td>
 			     
                  </tr>
 				<?php  }?>
 			</table>
             </div>
    </form>
</body>
</html>
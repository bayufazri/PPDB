<?php

include '../config/koneksi.php';
include '../library/controllers.php';

$perintah = new oop();

@$table = "tb_orangtua_wali";
@$where = "id_wali = $_GET[id]";
@$redirect = "?menu=orangtua_wali";
@$tanggal = $_POST['thn'] . "-" . $_POST['bln'] . "-" . $_POST['tgl'];
@$field = array('nama_wali' => $_POST['nama_wali'], 'tempat_lahir_wali' => $_POST['tempat_lahir_wali'], 'tanggal_lahir_wali' => $tanggal, 'pekerjaan_wali' => $_POST['pekerjaan_wali'], 'pendidikan_terakhir_wali' => $_POST['pendidikan_terakhir_wali'],'hubungan_dengan_murid' => $_POST['hubungan_dengan_murid'],'kewarganegaraan_wali' => $_POST['kewarganegaraan_wali'],'agama_wali' => $_POST['agama_wali'], 'no_hp_wali' => $_POST['no_hp_wali'], 'alamat_email' => $_POST['alamat_email']);    
    


if (isset($_POST['simpan'])) {
    $perintah->simpan($con, $table, $field, $redirect);
}

if (isset($_GET['hapus'])) {
    $perintah->hapus($con, $table, $where, $redirect);
}

if (isset($_GET['edit'])) {
    $edit = $perintah->edit($con, $table, $where);
    $date = explode("-", $edit['tanggal_lahir_wali']);
    $thn = $date[0];
    $bln = $date[1];
    $tgl = $date[2];
}

if (isset($_POST['ubah'])) {
    $perintah->ubah($con, $table, $field, $where, $redirect);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Ibu</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
<body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<form action="" method="post" enctype="multipart/form-data">
    <table>
    <div class="container">
    <br>
    <div class="form-row">
        <div class="form-group col-md-6">
			<h6>Nama Ibu</h6>
			<input type="text" class="form-control" name="nama_wali" placeholder="Nama Wali" value="<?php echo @$edit['nama_wali'] ?>" required>
		</div>
        <div class="form-group col-md-6">
			<h6>Tempat Lahir</h6>
			<input type="text" class="form-control" name="tempat_lahir_wali" placeholder="Tempat lahir" value="<?php echo @$edit['tempat_lahir_wali'] ?>" required>
		</div>
	</div>
    <div class="form-row">
    <div class="form-group col-md-6">
			<h6>Tanggal Lahir</h6>
            <div class="form-group">
             <select name="tgl" class="form-control col-md-3 custom-control-inline" required>
                    <option value="<?php echo @$tgl ?>"><?php echo @$tgl ?></option>
                    <?php
                    for ($tgl = 1; $tgl <= 31; $tgl++) {
                        if ($tgl <= 9) {
                            ?>
                            <option value="<?php echo "0" . $tgl; ?>"><?php echo "0" . $tgl; ?></option>
                        <?php } else { ?>
                            <option value="<?php echo $tgl; ?>"><?php echo $tgl; ?></option>            
                        <?php }
                    } ?>
                </select>

                <select name="bln" class="form-control col-md-3 custom-control-inline" required>
                    <option value="<?php echo @$bln; ?>"><?php echo @$bln; ?></option>
                    <?php
                    for ($bln = 1; $bln <= 12; $bln++) {
                        if ($bln <= 9) {
                            ?>
                            <option value="<?php echo "0" . $bln; ?>"><?php echo "0" . $bln; ?></option>
                        <?php } else {
                            ; ?>
                            <option value="<?php echo $bln; ?>"><?php echo $bln; ?></option>
                        <?php }
                            } ?>
                </select>

                <select name="thn" class="form-control col-md-4  custom-control-inline" required>
                    <option value="<?php echo @$thn; ?>"><?php echo @$thn; ?></option>
                    <?php
                    for ($thn = 1996; $thn <= 2005; $thn++) {
                        ?>
                        <option value="<?php echo $thn; ?>"><?php echo $thn; ?></option>
                    <?php } ?>
                </select>
                </div>
                </div>
            </td>
        </tr>
        <div class="form-group col-md-6">
			<h6>Pekerjaaan</h6>
			<input type="text" class="form-control" name="pekerjaan_wali" placeholder="Pekerjaan" value="<?php echo @$edit['pekerjaan_wali'] ?>" required>
		</div>
	</div>
    <div class="form-row">
        <div class="form-group col-md-6">
			<h6>Pendidikan Terakhir</h6>
			<input type="text" class="form-control" name="pendidikan_terakhir_wali" placeholder="Pendidikan Terakhir" value="<?php echo @$edit['pendidikan_terakhir_wali'] ?>" required>
		</div>
	
        <div class="form-group col-md-6">
			<h6>Hubungan Dengan Murid</h6>
			<input type="text" class="form-control" name="hubungan_dengan_murid" placeholder="Hubungan Dengan Murid" value="<?php echo @$edit['hubungan_dengan_murid'] ?>" required>
		</div>
	</div>
    <div class="form-row">
    <div class="form-group col-md-6">
			<h6>Kewarganegaraan</h6>
			<input type="text" class="form-control" name="kewarganegaraan_wali" placeholder="Kewarganegaraan" value="<?php echo @$edit['kewarganegaraan_wali'] ?>" required>
		</div>
        <div class="form-group col-md-6">
			<h6>Agama</h6>
			<input type="text" class="form-control" name="agama_ibu" placeholder="Agama" value="<?php echo @$edit['agama_ibu'] ?>" required>
		</div>
	</div>
    <div class="form-row">
    <div class="form-group col-md-6">
			<h6>No Hp</h6>
			<input type="text" class="form-control" name="no_hp_wali" placeholder="No Hp/WA" value="<?php echo @$edit['no_hp_wali'] ?>" required>
		</div>
        <div class="form-group col-md-6">
			<h6>Alamat Email</h6>
			<input type="text" class="form-control" name="alamat_email" placeholder="Alamat Email" value="<?php echo @$edit['alamat_email'] ?>" required>
		</div>
	</div>
    <div class="form-row">
    <div class="form-group col-md-2">
    <?php if (@$_GET['id'] == "") { ?>
        <input type="submit" href="?menu=orangtua_wali" class="form-control btn btn-primary" name="simpan" value="Simpan">
                <?php } else { ?>
        <input type="submit" href="?menu=orangtua_wali" class="form-control btn btn-primary" name="ubah" value="Ubah">
                    <?php } ?>
		</div>
              <div>
</div>
        </tr>
    </table>
    <div class="container">
    <table class="table table-striped">
 				<tr>
 					<td scope="col">No.</td>
 					<td scope="col">Nama Ibu</td>
 					<td scope="col">tempat_lahir</td>
 					<td scope="col">tanggal_lahir</td>
 					<td scope="col">pekerjaan</td>
 					<td scope="col">pendidikan Terakhir</td>
                     <td scope="col">Hubungan Dengan Murid</td>
 					<td scope="col">Kewarganegaraan</td>
                    <td scope="col">agama</td>
                    <td scope="col">No Hp</td>
                    <td scope="col">Alamat Email</td>
                    <td colspan="3">Aksi</td>
 				</tr>
                 <?php 
 				$no = 0;
 				$sql = mysqli_query($con, "SELECT * FROM tb_orangtua_wali");
 				while ($r = mysqli_fetch_array($sql)){
 					$no++;
 				 ?>
 				 <tr>
 				 	<td><?php echo $no; ?></td>
                    <td><?php echo $r['nama_wali']; ?></td>
 				 	<td><?php echo $r['tempat_lahir_wali']; ?></td>
 				 	<td><?php echo $r['tanggal_lahir_wali']; ?></td>
 				 	<td><?php echo $r['pekerjaan_wali']; ?></td>
                    <td><?php echo $r['pendidikan_terakhir_wali']; ?></td> 
                    <td><?php echo $r['hubungan_dengan_murid']; ?></td> 
                    <td><?php echo $r['kewarganegaraan_wali']; ?></td>
                    <td><?php echo $r['agama_wali']; ?></td>
                    <td><?php echo $r['no_hp_wali']; ?></td>
                    <td><?php echo $r['alamat_email']; ?></td> 
 				 	<td><a href="?menu=orangtua_wali&hapus&id=<?php echo $r['id_wali'] ?> "on_Click = "return confirm('Anda Yakin?')">Hapus</a></td>
                    <td><a href="?menu=orangtua_wali&edit&id=<?php echo $r['id_wali'] ?>">Edit</a></td>
 			     
                  </tr>
 				<?php  }?>
 			</table>
             </div>
    </form>
</body>
</html>
<?php

include '../config/koneksi.php';
include '../library/controllers.php';

$perintah = new oop();

@$table = "tb_siswa";
@$where = "id_siswa = $_GET[id]";
@$redirect = "?menu=calontadik";
@$tanggal = $_POST['thn'] . "-" . $_POST['bln'] . "-" . $_POST['tgl'];
@$folder = "../foto";


if (isset($_POST['simpan'])) {
    $foto = $_FILES['foto'];
    $upload = $perintah->upload($foto, $folder);
    $field = array('no_daftar' => $_POST['no_daftar'], 'jalur' => $_POST['jalur'], 'nama_lengkap' => $_POST['nama_lengkap'], 'nama_panggilan' => $_POST['nama_panggilan'], 'jenis_kelamin' => $_POST['jenis_kelamin'], 'tempat_lahir' => $_POST['tempat_lahir'],'tanggal_lahir' => $tanggal, 'agama' => $_POST['agama'], 'cita_cita' => $_POST['cita_cita'], 'hoby' => $_POST['hoby'], 'anak_ke' => $_POST['anak_ke'], 'jml_saudara_kandung' => $_POST['jml_saudara_kandung'], 'jml_saudara_tiri' => $_POST['jml_saudara_tiri'], 'jml_saudara_angkat' => $_POST['jml_saudara_angkat'], 'berat_badan' => $_POST['berat_badan'], 'tinggi_badan' => $_POST['tinggi_badan'], 'golongan_darah' => $_POST['golongan_darah'],'foto' => $upload);    
    $perintah->simpan($con, $table, $field, $redirect);
}

if (isset($_GET['hapus'])) {
    $perintah->hapus($con, $table, $where, $redirect);
}

if (isset($_GET['edit'])) {
    $edit = $perintah->edit($con, $table, $where);
    if ($edit['jalur'] == "reguler") {
        $e = "checked";
    } else {
        $b = "checked";
    }
    if ($edit['jenis_kelamin'] == "L") {
        $l = "checked";
    } else {
        $p = "checked";
    }
    $date = explode("-", $edit['tanggal_lahir']);
    $thn = $date[0];
    $bln = $date[1];
    $tgl = $date[2];
}

if (isset($_POST['ubah'])) {
    $foto = $_FILES['foto'];
    $upload = $perintah->upload($foto, $folder);
    if (empty($_FILES['foto']['name'])) {
        $field = array('no_daftar' => $_POST['no_daftar'], 'jalur' => $_POST['jalur'], 'nama_lengkap' => $_POST['nama_lengkap'], 'nama_panggilan' => $_POST['nama_panggilan'], 'jenis_kelamin' => $_POST['jenis_kelamin'], 'tempat_lahir' => $_POST['tempat_lahir'],'tanggal_lahir' => $tanggal, 'agama' => $_POST['agama'], 'cita_cita' => $_POST['cita_cita'], 'hoby' => $_POST['hoby'], 'anak_ke' => $_POST['anak_ke'], 'jml_saudara_kandung' => $_POST['jml_saudara_kandung'], 'jml_saudara_tiri' => $_POST['jml_saudara_tiri'], 'jml_saudara_angkat' => $_POST['jml_saudara_angkat'], 'berat_badan' => $_POST['berat_badan'], 'tinggi_badan' => $_POST['tinggi_badan'], 'golongan_darah' => $_POST['golongan_darah'],'foto' => $upload);$perintah->ubah($con, $table, $field, $where, $redirect);
    } else {
        $field = array('no_daftar' => $_POST['no_daftar'], 'jalur' => $_POST['jalur'], 'nama_lengkap' => $_POST['nama_lengkap'], 'nama_panggilan' => $_POST['nama_panggilan'], 'jenis_kelamin' => $_POST['jenis_kelamin'], 'tempat_lahir' => $_POST['tempat_lahir'],'tanggal_lahir' => $tanggal, 'agama' => $_POST['agama'], 'cita_cita' => $_POST['cita_cita'], 'hoby' => $_POST['hoby'], 'anak_ke' => $_POST['anak_ke'], 'jml_saudara_kandung' => $_POST['jml_saudara_kandung'], 'jml_saudara_tiri' => $_POST['jml_saudara_tiri'], 'jml_saudara_angkat' => $_POST['jml_saudara_angkat'], 'berat_badan' => $_POST['berat_badan'], 'tinggi_badan' => $_POST['tinggi_badan'], 'golongan_darah' => $_POST['golongan_darah'],'foto' => $upload);
        $perintah->ubah($con, $table, $field, $where, $redirect);
    }
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Siswa</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
<body>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<form action="" method="post" enctype="multipart/form-data">
    <table>
    <div class="container">
    <br>
    <div class="form-row">
        <div class="form-group col-md-6">
			<h6>No Tes</h6>
			<input type="text" class="form-control" name="no_daftar" placeholder="No Tes" value="<?php echo @$edit['no_daftar'] ?>" required>
		</div>
            <h6>Jalur</h6>
            <div class="form-group col-md-2">
        <div class="custom-control custom-radio custom-control-inline ">
            <input type="radio" id="ContohRadio1" name="jalur" value="reguler" class="custom-control-input" <?php echo @$e ?> required>
            <label class="custom-control-label" for="ContohRadio1">Reguler</label>
        </div>
        <div class="custom-control custom-radio custom-control-inline">
            <input type="radio" id="ContohRadio2" name="jalur" value="beasiswa"  class="custom-control-input" <?php echo @$b ?> required>
            <label class="custom-control-label" for="ContohRadio2">Beasiswa</label>
        </div>
            </div>
        </div>
    <div class="form-row">
        <div class="form-group col-md-6">
			<h6>Nama Lengkap</h6>
			<input type="text" class="form-control" name="nama_lengkap" placeholder="Nama Lengkap" value="<?php echo @$edit['nama_lengkap'] ?>" required>
		</div>
        <div class="form-group col-md-6">
			<h6>Nama Panggilan</h6>
			<input type="text" class="form-control" name="nama_panggilan" placeholder="Nama Panggilan" value="<?php echo @$edit['nama_panggilan'] ?>" required>
		</div>
	</div>

    <div class="form-row">
        <h6>Jenis Kelamin</h6>
        <div class="form-group col-md-2">
	<div class="custom-control custom-radio custom-control-inline ">
		<input type="radio" id="ContohRadio1" name="jenis_kelamin" value="laki-laki" class="custom-control-input" <?php echo @$l ?> required>
		<label class="custom-control-label" for="ContohRadio1">Laki-laki</label>
	</div>
	<div class="custom-control custom-radio custom-control-inline">
		<input type="radio" id="ContohRadio2" name="jenis_kelamin" value="perempuan"  class="custom-control-input"<?php echo @$p ?> required>
		<label class="custom-control-label" for="ContohRadio2">Perempuan</label>
        </div>
    </div>
        <div class="form-row">
    <div class="form-group col-md-15">
			<h6>Tempat Lahir</h6>
			<input type="text" class="form-control" name="tempat_lahir" placeholder="Tempat lahir" value="<?php echo @$edit['tempat_lahir'] ?>" required>
		</div>
		</div>
        <div class="form-group col-md-6">
			<h6>Tanggal Lahir</h6>
            <div class="form-group">
             <select name="tgl" class="form-control col-md-3 custom-control-inline" required>
                    <option value="<?php echo @$tgl ?>"><?php echo @$tgl ?></option>
                    <?php
                    for ($tgl = 1; $tgl <= 31; $tgl++) {
                        if ($tgl <= 9) {
                            ?>
                            <option value="<?php echo "0" . $tgl; ?>"><?php echo "0" . $tgl; ?></option>
                        <?php } else { ?>
                            <option value="<?php echo $tgl; ?>"><?php echo $tgl; ?></option>            
                        <?php }
                    } ?>
                </select>

                <select name="bln" class="form-control col-md-3 custom-control-inline" required>
                    <option value="<?php echo @$bln; ?>"><?php echo @$bln; ?></option>
                    <?php
                    for ($bln = 1; $bln <= 12; $bln++) {
                        if ($bln <= 9) {
                            ?>
                            <option value="<?php echo "0" . $bln; ?>"><?php echo "0" . $bln; ?></option>
                        <?php } else {
                            ; ?>
                            <option value="<?php echo $bln; ?>"><?php echo $bln; ?></option>
                        <?php }
                            } ?>
                </select>

                <select name="thn" class="form-control col-md-4  custom-control-inline" required>
                    <option value="<?php echo @$thn; ?>"><?php echo @$thn; ?></option>
                    <?php
                    for ($thn = 1996; $thn <= 2005; $thn++) {
                        ?>
                        <option value="<?php echo $thn; ?>"><?php echo $thn; ?></option>
                    <?php } ?>
                </select>
                </div>
                </div>
            </td>
        </tr>
	</div>

    <div class="form-row">
        <div class="form-group col-md-6">
			<h6>Agama</h6>
			<input type="text" class="form-control" name="agama" placeholder="Agama" value="<?php echo @$edit['agama'] ?>" required>
		</div>
        <div class="form-group col-md-6">
			<h6>Cita - cita</h6>
			<input type="text" class="form-control" name="cita_cita" placeholder="Cita - Cita" value="<?php echo @$edit['cita_cita'] ?>" required>
		</div>
	</div>

    <div class="form-row">
        <div class="form-group col-md-6">
			<h6>Hoby</h6>
			<input type="text" class="form-control" name="hoby" placeholder="Hoby" value="<?php echo @$edit['hoby'] ?>" required>
		</div>
        <div class="form-group col-md-6">
			<h6>Anak Ke</h6>
			<input type="text" class="form-control" name="anak_ke" placeholder="Anak Ke" value="<?php echo @$edit['anak_ke'] ?>" required>
		</div>
	</div>
        
    <div class="form-row">
        <div class="form-group col-md-4">
			<h6>Jumlah Saudara Kandung</h6>
			<input type="text" class="form-control" name="jml_saudara_kandung" placeholder="Jumlah Saudara Kandung" value="<?php echo @$edit['jml_saudara_kandung'] ?>" required>
		</div>
        <div class="form-group col-md-4">
			<h6>Jumlah Saudara Kandung</h6>
			<input type="text" class="form-control" name="jml_saudara_angkat" placeholder="Jumlah Saudara Angkat" value="<?php echo @$edit['jml_saudara_angkat'] ?>" required>
		</div>
        <div class="form-group col-md-4">
			<h6>Jumlah Saudara Kandung</h6>
			<input type="text" class="form-control" name="jml_saudara_tiri" placeholder="Jumlah Saudara Tiri" value="<?php echo @$edit['jml_saudara_tiri'] ?>" required>
		</div>
        </div>
 
        <div class="form-row">
        <div class="form-group col-md-4">
			<h6>Berat Badan</h6>
			<input type="text" class="form-control" name="berat_badan" placeholder="Berat Badan" value="<?php echo @$edit['berat_badan'] ?>" required>
		</div>
        <div class="form-group col-md-4">
			<h6>Tinggi Badan</h6>
			<input type="text" class="form-control" name="tinggi_badan" placeholder="Tinggi Badan" value="<?php echo @$edit['tinggi_badan'] ?>" required>
		</div>
        <div class="form-group col-md-4">
			<h6>Golongan Darah</h6>
			<input type="text" class="form-control" name="golongan_darah" placeholder="Golongan Darah" value="<?php echo @$edit['golongan_darah'] ?>" required>
		</div>
        </div>
       
       
        <div class="form-row">
        <div class="form-group col-md-4">
			<h6>Foto</h6>
			<input type="file" class="form-control" name="foto" value="<?php echo @$edit['foto'] ?>" required>
		</div>
        
        <div class="form-group col-md-2">
        <?php if (@$_GET['id'] == "") { ?>
        <input type="submit" href="?menu=raport" class="form-control btn btn-primary" name="simpan" value="Simpan">
                <?php } else { ?>
        <input type="submit" href="?menu=raport" class="form-control btn btn-primary" name="ubah" value="Ubah">
                    <?php } ?>
		</div>
        </div>
        </table>
        <div class="container">
    <table class="table table-striped">
    
 				<tr>
 					<td scope="col">No.</td>
                    <td scope="col">No Peserta</td>
 					<td scope="col">No Tes</td>
 					<td scope="col">Jalur</td>
 					<td scope="col">Nama Lengkap</td>
 					<td scope="col">Nama Panggilan</td>
 					<td scope="col">Jenis Kelamin</td>
 					<td scope="col">Tempat Lahir</td>
                    <td scope="col">Tanggal Lahir</td>
                    <td scope="col">Agama</td>
                    <td scope="col">Cita-cita</td>
                    <td scope="col">Hoby</td>
                    <td scope="col">Anak Ke</td>
                    <td scope="col">Saudara kandung</td>
                    <td scope="col">Saudara tiri</td>
                    <td scope="col">Saudra angkat</td>
                    <td scope="col">Berat Badan</td>
                    <td scope="col">Tinggi Badan</td>
                    <td scope="col">Golongan Darah</td>
                    <td scope="col">Foto</td>
                    <td colspan="3">Aksi</td>
 				</tr>
                <?php 
                $no = 0;
                $sql = mysqli_query($con, "SELECT * FROM tb_siswa");
                while ($r = mysqli_fetch_array($sql)){
                    $no++;
                 ?>
 				 <tr>
 				 	<td><?php echo $no; ?></td>
                    <td><?php echo $r['id_siswa']; ?></td>
 				 	<td><?php echo $r['no_daftar']; ?></td>
 				 	<td><?php echo $r['jalur']; ?></td>
 				 	<td><?php echo $r['nama_lengkap']; ?></td>
                    <td><?php echo $r['nama_panggilan']; ?></td> 
                    <td><?php echo $r['jenis_kelamin']; ?></td>
                    <td><?php echo $r['tempat_lahir']; ?></td>
                    <td><?php echo $r['tanggal_lahir']; ?></td>
                    <td><?php echo $r['agama']; ?></td>
                    <td><?php echo $r['cita_cita']; ?></td>
                    <td><?php echo $r['hoby']; ?></td>
                    <td><?php echo $r['anak_ke']; ?></td>
                    <td><?php echo $r['jml_saudara_kandung']; ?></td>
                    <td><?php echo $r['jml_saudara_tiri']; ?></td>
                    <td><?php echo $r['jml_saudara_angkat']; ?></td>
                    <td><?php echo $r['berat_badan']; ?></td>
                    <td><?php echo $r['tinggi_badan']; ?></td>
                    <td><?php echo $r['golongan_darah']; ?></td>
 				 	<td><img src="../foto/<?php echo $r['foto'] ?>" width="50" height="50" /></td>
 				 	<td><a href="?menu=calontadik&hapus&id=<?php echo $r['id_siswa'] ?> "on_Click = "return confirm('Anda Yakin?')">Hapus</a></td>
                    <td><a href="?menu=calontadik&edit&id=<?php echo $r['id_siswa'] ?>">Edit</a></td>
 			     
                  </tr>
 				<?php  }?>
 			</table>
    </form>
    </div>
</body>
</html>